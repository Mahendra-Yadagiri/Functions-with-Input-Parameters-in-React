import React, { useRef} from 'react'

function MarksSheet() {
    let firstNameRef=useRef();
    let lastNameRef=useRef();
    let resultLabelRef=useRef();
    let engInputRef=useRef();
    let telInputRef=useRef();
    let hinInputRef=useRef();
    let matInputRef=useRef();
    let sciInputRef=useRef();
    let socInputRef=useRef();
    let btnInputRef=useRef();
   

    

    let engSpanRef=useRef();
    let telSpanRef=useRef();
    let hinSpanRef=useRef();
    let matSpanRef=useRef();
    let sciSpanRef=useRef();
    let socSpanRef=useRef();

    let calculateResult=()=>{
  
       let firstName=firstNameRef.current.value;
               let lastName=lastNameRef.current.value;
               let engMarks=Number(engInputRef.current.value);
               let telMarks=Number(telInputRef.current.value);
               let hinMarks=Number(hinInputRef.current.value);
               let matMarks=Number(matInputRef.current.value);
               let sciMarks=Number(sciInputRef.current.value);
               let socMarks=Number(socInputRef.current.value);

               let result;
               let totalMarks=engMarks+telMarks+hinMarks+matMarks+sciMarks+socMarks;
                 
               let perc=totalMarks/600*100
              
                
          
         





 if(engMarks < 35 ||telMarks < 35 ||
                hinMarks < 35 || matMarks < 35 ||
                sciMarks < 35 || socMarks < 35
               ){
                 result="Failed"
               }else{
                result= "Passed"
               }


               resultLabelRef.current.innerHTML=`Mr.${firstName} ${lastName} has ${result}  in tenth.  Total marks : ${totalMarks} with ${perc.toFixed(2)}%`
      

      

// if (totalMarks > 600 || totalMarks === 0) {
//     btnInputRef.current.disabled = true;   // disabled
//   } else {
//     btnInputRef.current.disabled = false;  // enabled
//   }


        console.log("Inside Calculate Result")
    }
    let inputOnFocus=(inputRef,bgColor="violet")=>{
        inputRef.current.style.backgroundColor=bgColor;
    }
    let inputOnBlur=(inputRef)=>{
        inputRef.current.style.backgroundColor=""

    }
    let inputOnChange=(inputRef,spanRef)=>{

        let marks=inputRef.current.value
                  if (marks>=0 && marks <=100){

                    if(marks >=35){
                        spanRef.current.innerHTML="🤠 Pass";
                        spanRef.current.style.backgroundColor="brown"

                    }else{
                        spanRef.current.innerHTML="😖 Fail";
                        spanRef.current.style.backgroundColor="black";

                    }   
                    // btnInputRef.current.style.display="inline-block"
                     btnInputRef.current.disabled=false

                  }else{
                    spanRef.current.innerHTML="invalid";
                    spanRef.current.style.backgroundColor="rgba(126, 139, 21, 1)"
                     btnInputRef.current.disabled=true

                  }

    }

    

    
    
    
  return (

    <div >
        <form>
            <h2>Marks Sheet</h2>

            <div>
                <label>First Name:</label>
                <input ref={firstNameRef} type="text"  maxlength="10" placeholder="Initial-Name"
                onFocus={()=>{
                    inputOnFocus(firstNameRef,"aqua")
                   

                }}
                onChange={()=>{
                    firstNameRef.current.style.backgroundColor="yellow";
                    
                }}
                onBlur={()=>{
                   inputOnBlur(firstNameRef)
                }}></input>
                <span></span>
            </div>

            <div>
                <label>Last Name:</label>
                <input ref={lastNameRef} type="text" maxlength="10" placeholder="Name" required
                onFocus={()=>{
                   inputOnFocus(lastNameRef,"blue");

                }}
                onChange={()=>{
                    lastNameRef.current.style.backgroundColor="yellow";
                    
                }}
                onBlur={()=>{
                    inputOnBlur(lastNameRef);
                }}></input>
                <span></span>
            </div>

            <div>
                <label>English:</label>
                <input ref={engInputRef} type="number" placeholder="Enter-Marks" required
                onFocus={()=>{
                  inputOnFocus(engInputRef,"green")
                }}
                onChange={()=>{ 
                    inputOnChange(engInputRef,engSpanRef)
                    
                }}
                onBlur={()=>{
                    
                    inputOnBlur(engInputRef)
                    
                }}></input>
                <span ref={engSpanRef}></span>
            </div>

            <div>
                <label>Telugu:</label>
                <input ref={telInputRef}  type="number" placeholder='Enter-Marks'  required
                onFocus={()=>{
                  inputOnFocus(telInputRef,"brown")
                   
                }}
                onChange={()=>{
                    
                    inputOnChange(telInputRef,telSpanRef)                  
                }}
                onBlur={()=>{
                    inputOnBlur(telInputRef);
                   
                   
                }}></input>
                <span ref={telSpanRef}></span>
            </div>

            <div>
                <label>Hindi:</label>
                <input ref={hinInputRef}  type="number"  placeholder='Enter-Marks' required
                onFocus={()=>{
                    inputOnFocus(hinInputRef,"orange")
                    
                }}
                onChange={()=>{
                    inputOnChange(hinInputRef,hinSpanRef)
                         
                }}
                onBlur={()=>{
                    
                   inputOnBlur(hinInputRef)

                }}></input>
                <span ref={hinSpanRef}></span>
            </div>

            <div>
                <label>Maths:</label>
                <input ref={matInputRef} type="number"  placeholder='Enter-Marks' required
                onFocus={()=>{
                    inputOnFocus(matInputRef,"rgb(77, 144, 196)")
                    
                }}
                onChange={()=>{
                inputOnChange(matInputRef,matSpanRef)
               
                }}
                onBlur={()=>{
                  inputOnBlur(matInputRef)
                    
                    
                }}

                ></input>
                <span ref={matSpanRef}></span>
            </div>
            <div>
                <label>Science:</label>
                <input ref={sciInputRef} type="number" placeholder='Enter-Marks' required
                onFocus={()=>{
                   inputOnFocus(sciInputRef)
                    
                }}
                onChange={()=>{
                    inputOnChange(sciInputRef,sciSpanRef)
                 
                }}
                onBlur={()=>{
                    inputOnBlur(sciInputRef)
                    

                }}></input>
                <span ref={sciSpanRef}></span>
            </div>

            <div>
                <label>Social:</label>
                <input ref={socInputRef} type="number" placeholder='Enter-Marks' required
                onFocus={()=>{
                    inputOnFocus(socInputRef)
                    

                }}
                onChange={()=>{
                    inputOnChange(socInputRef,socSpanRef)       
                    
                }}
                onBlur={()=>{
                    inputOnBlur(socInputRef)
                    
                }}></input>
                <span ref={socSpanRef}></span>
            </div>
            <div>
            <button type="button"  ref={btnInputRef}  onClick={()=>{
      calculateResult();


            }}>Calculate</button>
            </div>
            <div>
                <label ref={resultLabelRef}
                className="innerLabel">Please  enter your values</label>
          </div>
        </form>

      
    </div>
  )
}

export default MarksSheet




