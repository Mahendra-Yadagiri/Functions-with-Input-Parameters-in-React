import React from 'react'

function Parameters() {

    let calculateStudentResult=(engMarks,telMarks,hinMarks,matMarks,sciMarks,socMarks,studentName)=>{
        let passmarks=35
        if(engMarks>=passmarks &&
            telMarks>=passmarks &&
            hinMarks>=passmarks &&
            matMarks>=passmarks &&
            sciMarks>=passmarks &&
            socMarks>=passmarks

        ){
            console.log(`${studentName}  Passed in Tenth`)

        }else{
            console.log(`${studentName}  Failed in Tenth`)
        }

    }
    calculateStudentResult(56,85,96,85,96,8,"virat");
    calculateStudentResult(52,74,91,53,74,65,"dhoni");
    calculateStudentResult(52,74,91,53,74,65,"mahi");
    calculateStudentResult(52,74,91,53,74,65,"rahul");
    calculateStudentResult(52,74,91,53,74,65,"dhanush");
    

















    // let  calculateDhoniResult=()=>{
    //     let engMarks=65;
    //     let telMarks=52;
    //     let hinMarks=32;
    //     let matMarks=56;
    //     let sciMarks=45;
    //     let socMarks=58;

    //     if(engMarks>=35 &&
    //         telMarks>=35 &&
    //         hinMarks>=35 &&
    //         matMarks>=35 &&
    //         sciMarks>=35 &&
    //         socMarks>=35
            
    //     ){
    //         console.log(`Dhoni Passed in Tenth`)

    //     }else{

    //         console.log(`Dhoni Failed in Tenth`)
    //     }
    // }


    //  let  calculateViratResult=()=>{
    //     let engMarks=65;
    //     let telMarks=52;
    //     let hinMarks=36;
    //     let matMarks=56;
    //     let sciMarks=45;
    //     let socMarks=58;

    //     if(engMarks>=35 &&
    //         telMarks>=35 &&
    //         hinMarks>=35 &&
    //         matMarks>=35 &&
    //         sciMarks>=35 &&
    //         socMarks>=35
            
    //     ){
    //         console.log(`Virat Passed in Tenth`)

    //     }else{

    //         console.log(`virat Failed in Tenth`)
    //     }
    // }

    // calculateDhoniResult();
    // calculateViratResult();


  return (
    <div>
      <h1>Functions with Input(Parameters)</h1>
    </div>
  )
}

export default Parameters
