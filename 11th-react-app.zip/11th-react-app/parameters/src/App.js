import './App.css';
import MarksSheet from './components/MarksSheet';
import Parameters from './components/Parameters';

function App() {
  return (
    <div className="App">
      <Parameters></Parameters>
      <MarksSheet></MarksSheet>
      
    </div>
  );
}

export default App;
